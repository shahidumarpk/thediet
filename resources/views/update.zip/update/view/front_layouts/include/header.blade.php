
<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
            <!--
            CSS
            ============================================= -->
            <link rel="stylesheet" href="{{ asset('public/front/assets/css/linearicons.css')}}">
            <link rel="stylesheet" href="{{ asset('public/front/assets/css/font-awesome.min.css')}}">
            <link rel="stylesheet" href="{{ asset('public/front/assets/css/bootstrap.css')}}">
            <link rel="stylesheet" href="{{ asset('public/front/assets/css/magnific-popup.css')}}">
            <link rel="stylesheet" href="{{ asset('public/front/assets/css/nice-select.css')}}">                          
            <link rel="stylesheet" href="{{ asset('public/front/assets/css/animate.min.css')}}">
            <link rel="stylesheet" href="{{ asset('public/front/assets/css/jquery-ui.css')}}">            
            <link rel="stylesheet" href="{{ asset('public/front/assets/css/owl.carousel.css')}}">
            <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
            <link rel="stylesheet" href="{{ asset('public/front/assets/css/main.css')}}">

